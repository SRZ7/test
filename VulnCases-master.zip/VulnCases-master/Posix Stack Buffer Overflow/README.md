# Linux Stack Buffer Overflow

This is an example of a stack buffer overflow for a custom Linux HTTP server.