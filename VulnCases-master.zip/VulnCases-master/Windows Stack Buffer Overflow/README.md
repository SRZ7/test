# Windows Stack Buffer Overflow

Ahh, the classic stack buffer overflow. These bugs still exist today. This is actually the exact
same challenge from Metasploit's Nov 2018 CTF, where people only had one way to break into the
Windows machine... yup, it was this challenge.